var Tasks = require("../controllers/tasks.js");

module.exports = function(app) {
  app.get("/tasks", function(request, response) {
    Tasks.get_tasks(request, response);
  });

  app.post("/tasks", function(request, response) {
    Tasks.post_tasks(request, response);
  });

  app.get("/showTask/:id", function(request, response) {
    Tasks.showTask(request, response);
  });

  app.put("/updateTask/:id", function(request, response) {
    Tasks.updateTask(request, response);
  });

  app.delete("/deleteTask/:id", function(request, response) {
    Tasks.deleteTask(request, response);
  });
};
